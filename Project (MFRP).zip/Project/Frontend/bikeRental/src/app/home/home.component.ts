import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { bikeDetailsClass } from '../Idata';
import { SharedService } from '../shared.service';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { DatePickerComponent } from '../date-picker/date-picker.component';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  widgetsContent: any;
  date = new Date();
  dateStringControl = new FormControl('Date');
  dateObjectControl = new FormControl(new Date());

  minDate: any;
  minDate1:any;

  startDate:any;
  
  selectedValue: any;


  pickupDate:any;
  dropoffDate:any;
  pickupTime:any;
  dropoffTime:any;

  clickedBookbutton(){
    
    const bookedHours=((this.dropoffDate.getTime()-this.pickupDate.getTime())/60/60000)+this.dropoffTime-this.pickupTime;

    sessionStorage.setItem("pickupDate",this.pickupDate);
    sessionStorage.setItem("dropoffDate",this.dropoffDate);
    sessionStorage.setItem("pickupTime",this.pickupTime);
    sessionStorage.setItem("dropoffTime",this.dropoffTime);
    sessionStorage.setItem("bookedHours",bookedHours.toString());

    console.log(((this.dropoffDate.getTime()-this.pickupDate.getTime())/60/60000)+this.dropoffTime-this.pickupTime);


    
  }

  times=[
    {
      value:8,
      text:"8:00am"
    },
    {
      value:9,
      text:"9:00am"
    },
    {
      value:10,
      text:"10:00am"
    },
    {
      value:11,
      text:"11:00am"
    },
    {
      value:12,
      text:"12:00pm"
    },
    {
      value:13,
      text:"1:00pm"
    },
    {
      value:14,
      text:"2:00pm"
    },
    {
      value:15,
      text:"3:00pm"
    },
    {
      value:16,
      text:"4:00pm"
    },
    {
      value:17,
      text:"5:00pm"
    },
    {
      value:18,
      text:"8:00pm"
    },
    {
      value:19,
      text:"7:00pm"
    },
    {
      value:20,
      text:"8:00pm"
    },
    {
      value:21,
      text:"9:00pm"
    },
    {
      value:22,
      text:"10:00pm"
    }

  ]


updateDate(event: any) {
this.date = event.target.valueAsDate;
}

  constructor(
    public service:SharedService,
    public dialog:MatDialog
  ) { 
    
  }

  ngOnInit(): void {
    const temp=new Date().getFullYear();
    const temp1=new Date().getMonth();
    const temp2=new Date().getDate();
    this.minDate=new Date(temp,temp1,temp2);
  }
  
  images=[
    'assets/images/main.jpg',
    'assets/images/main2.jpg',
    'assets/images/final.jpg',
    'assets/images/c1.png',
    'assets/images/c2.png',
    'assets/images/c3.jpg',
    'assets/images/c4.jpg',
    'assets/images/c5.png',
    'assets/images/c6.png',
    'assets/images/c7.png'

  ]
  bikes =[
    {
      name:'ROYAL ENFIELD HIMALAYAN',
      image:'https://d3vp2rl7047vsp.cloudfront.net/bike_models/images/000/000/273/medium/Himalayan_BS6.png?1581610903',
      id:'6214a6c4d0977c4a3036f47b',
      hourly_rate:'67'
    },
    {
      name:'BMW 310GS',
      image:'https://d3vp2rl7047vsp.cloudfront.net/bike_models/images/000/000/266/medium/bmw_gs_310.png?1571747527',
      id:'6214a774d0977c4a3036f47e',
      hourly_rate:'110'
    },
    {
      name:'JAWA STANDARD',
      image:'https://d3vp2rl7047vsp.cloudfront.net/bike_models/images/000/000/264/medium/jawa_maroon.png?1571325878',
      id:'6214b2e5d0977c4a3036f497',
      hourly_rate:'57'
    }
  ]

  openDialog(bikeId:any,hourly_rate:any){
    console.log(bikeId);
    sessionStorage.setItem("bikeId",bikeId);
    sessionStorage.setItem("hourly_Rate",hourly_rate.toString());

    const dialogConfig = new MatDialogConfig();
    this.dialog.open(DatePickerComponent,dialogConfig);
  }


}
