export class Session{
    isLoggedIn():boolean{
        return localStorage.getItem("userId")== null ? false : true;
    }

    logout(){
        localStorage.clear();
        sessionStorage.clear();
    }
}