const Bikes = require("../../models/bike.model");


module.exports = function (router) {

    router.get("/bikes", async (req, res) => {
        const bikes = await Bikes.find({}).lean().exec();
        res.status(200).json(bikes);
    });

    router.post("/bikes", function (req, res) {
        let bike = new Bikes(req.body)
        bike.save(function (err, note) {
            if (err) {
                return res.status(400).json(err)
            }
            res.status(200).json(note)
        })
    })

    router.get("/bikes/:id", async (req, res) => {
        const bikeId = req.params.id;
        const bikes = await Bikes.findById(bikeId).lean().exec();
        res.status(200).json(bikes);
    });



}