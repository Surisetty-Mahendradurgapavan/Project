const User = require('../../models/user.model');



module.exports = function (router) {
    // router.get("/users", async (req, res) => {
    //     const users = await User.find({});
    //     res.status(200).json(users);
    // });

    router.post("/users", function (req, res) {
        let user = new User(req.body)
        user.save(function (err, note) {
            if (err) {
                return res.status(404).json(err)
            }
            res.status(200).json({message:"registered"})
        })
    })

    router.get("/users/:id", async (req, res) => {
        const userId = req.params.id;
        const users = await User.findById(userId).lean().exec();
        res.status(200).json(users);
    })

    router.post("/loginuser", function (req, res) {
        const email = req.body.email;
        const password = req.body.password;
        User.findOne({ "email": email }, (err, user) => {
            if (err) {
                res.json({ status: false, message: err })
            } else if (!user) {
                res.json({ message: 'Please register before log in', id: null })
            } else if (user.password != password) {
                res.json({ message: 'Wrong Password!', id: null })
            } else {
                res.json({ message: "Success!", id: user._id })
            }
        })


    })

}