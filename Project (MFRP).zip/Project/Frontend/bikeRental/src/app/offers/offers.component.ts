import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {

  location='Alleppey';

  constructor() { }

  ngOnInit(): void {
    var temp:any=sessionStorage.getItem('location');
    if(temp==null){
      this.location='Alleppey';

    }else{
      this.location=temp;

    }
  }

}
