const express = require('express')

const router = express.Router()

require('./routes/bikes')(router)

require('./routes/location')(router)

require('./routes/user')(router)

require('./routes/rental')(router)

module.exports = router;