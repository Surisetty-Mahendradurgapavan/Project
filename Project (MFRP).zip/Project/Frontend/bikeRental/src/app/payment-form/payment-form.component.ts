import { Component, OnInit } from '@angular/core';
import { FormBuilder , FormGroup , Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { SharedService } from '../shared.service';
import { rentalDetailsClass } from '../Idata';


@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.css']
})
export class PaymentFormComponent implements OnInit {

  paymentForm!: FormGroup;
  displayMessage!: string;
  constructor(
    public service:SharedService,
    private formBuilder:FormBuilder,
    private router:Router
  ) { }

    rentalDetails = new rentalDetailsClass;
    bikeId:any=sessionStorage.getItem("bikeId");
    pickupDate:any=sessionStorage.getItem("pickupDate");
    pickupTime:any=sessionStorage.getItem("pickupTime");
    dropoffDate:any=sessionStorage.getItem("dropoffDate");
    dropoffTime:any=sessionStorage.getItem("dropoffTime");
    bookedHours:any=sessionStorage.getItem("bookedHours"); 
    userId:any=localStorage.getItem("userId"); 
    paid:any=Number(sessionStorage.getItem("paid"));
    gst=this.paid * (14/100);
  total=this.paid +this.gst +this.gst;

  ngOnInit(): void {
    this.buildForm();
    this.rentalDetails.userId=this.userId;
    this.rentalDetails.bikeId=this.bikeId;
    this.rentalDetails.pickup_date=this.pickupDate;
    this.rentalDetails.pickup_time=this.pickupTime;
    this.rentalDetails.drop_date=this.dropoffDate;
    this.rentalDetails.drop_time=this.dropoffTime;
    this.rentalDetails.paid=this.total.toString();
  }
  buildForm(){
      this.paymentForm = this.formBuilder.group({
        nameOnCard: ['',
        [Validators.required,
        Validators.minLength(1),
        Validators.pattern('^[A-Za-z][A-Za-z -]*$')
        ]
        ],
        cardNumber: ['',
        [Validators.required,
        Validators.minLength(16),
        Validators.min(1111111111111111),
        Validators.max(9999999999999999)
        ]
        ],
        expirationMonth: ['',
        [
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(2),
        Validators.min(1),
        Validators.max(12)
        ]
        ],
        expirationYear: ['',
        [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(4),
        Validators.min(1111),
        Validators.max(9999)
        ]
        ],
        cardCVVNumber: ['',
        [Validators.required,
        Validators.minLength(3),
        Validators.maxLength(3),
        Validators.min(111),
        Validators.max(999)
        ]
        ]
        });
    
  }
  get f() { return this.paymentForm.controls; }
  onSubmit() {
    this.submitForm();
  }
    
  submitForm() {
    /* Change the display message on button click / submit form */
    // stop here if form is invalid
    if (this.paymentForm.invalid) {
    this.displayMessage = "Payment Failed!";
    return;
    }
    this.displayMessage = "Payment Successful!";
  }
  goToHome(){
    this.service.postRental(this.rentalDetails).subscribe(data=>{
      console.log(data);
    })
    this.router.navigate(['/profile'])
  }

}
