import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { bikeDetailsClass, locationDetailsClass, pastRentalDetailsClass, rentalDetailsClass, userDetails, userDetailsClass, userLogin, userRegister } from './Idata';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(
    private http:HttpClient
  ) { }

  //getting one users
  public getUsers(id:string):Observable<userDetailsClass>{
    return this.http.get<userDetailsClass>('http://localhost:8083/api/users/'+id);
  }

  //registering a new user
  public registerUser(newUser:userRegister):Observable<any>{
    const headers = {'content-type':'application/json'}
    const body = JSON.stringify(newUser);
    return this.http.post('http://localhost:8083/api/users',body,{'headers':headers});

  }

  public logInUser(log:userLogin){
    const headers = {'content-type':'application/json'}
    const body = JSON.stringify(log);
    return this.http.post('http://localhost:8083/api/loginuser',body,{'headers':headers});
  }

  //bikes
  public getBikes():Observable<bikeDetailsClass[]>{
    return this.http.get<bikeDetailsClass[]>('http://localhost:8083/api/bikes')
  }
  public getOneBike(id:string):Observable<bikeDetailsClass>{
    return this.http.get<bikeDetailsClass>('http://localhost:8083/api/bikes/'+id);
  }

  //location
  public getLocations():Observable<locationDetailsClass[]>{
    return this.http.get<locationDetailsClass[]>('http://localhost:8083/api/locations')
  }


  //rental

  public postRental(rentalDetails:rentalDetailsClass):Observable<any>{
    const headers = {'content-type':'application/json'}
    const body = JSON.stringify(rentalDetails);
    return this.http.post('http://localhost:8083/api/rentals',body,{'headers':headers});
  }

  //get user rentals
  public getPastRentals(id:string):Observable<pastRentalDetailsClass[]>{
    return this.http.get<pastRentalDetailsClass[]>('http://localhost:8083/api/rentals/'+id);
  }
  

}
