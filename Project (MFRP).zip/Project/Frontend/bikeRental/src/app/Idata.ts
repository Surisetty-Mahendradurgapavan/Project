export interface userDetails{
    "createdAt": Date,
    "_id": string,
    "first_name": string,
    "last_name":string,
    "email": string,
    "password": string,
}

export class userDetailsClass{
    "createdAt": Date
    "_id": string
    "first_name": string
    "last_name":string
    "email": string
    "password": string
}

export class bikeDetailsClass{
    "_id": string
    "bike_name": string
    "bike_image": string
    "hourly_rate": number
    "kilometer_limit": number
    "locationId": string
}

export class rentalDetailsClass{
    "bikeId":string
    "userId":string
    "pickup_date":Date
    "pickup_time":string
    "drop_date":Date
    "drop_time":string
    "paid":number
}

export class pastRentalDetailsClass{
    "bikeId":any
    "userId":string
    "pickup_date":Date
    "pickup_time":string
    "drop_date":Date
    "drop_time":string
    "paid":number
}

export class locationDetailsClass{
    "_id":string
    "location_name":string
    "location_image":string
}


export class userRegister{
    "first_name":string
    "last_name":string
    "email":string
    "password":string
}

export class userLogin{
    "email":string
    "password":string
}

export class messages{
    "message":string
    "id":string
}



