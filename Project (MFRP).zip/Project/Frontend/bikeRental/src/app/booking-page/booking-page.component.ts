import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { bikeDetailsClass, rentalDetailsClass } from '../Idata';

import { Session } from '../session';

import { Router } from '@angular/router';

@Component({
  selector: 'app-booking-page',
  templateUrl: './booking-page.component.html',
  styleUrls: ['./booking-page.component.css']
})
export class BookingPageComponent implements OnInit {

  constructor(
    public service:SharedService,
    
    private router:Router
  ) { }
  tempDate = Date();
  pickupDate:any=sessionStorage.getItem("pickupDate");


  // pickupDate = ;
  dropoffDate:any = sessionStorage.getItem("dropoffDate");
  pickupTime:any = sessionStorage.getItem("pickupTime");
  dropoffTime:any = sessionStorage.getItem("dropoffTime");
  
  tempbookedHours = sessionStorage.getItem("bookedHours");

  userId:any = localStorage.getItem("userId");


  bookedHours = Number(this.tempbookedHours);


  bike_details:bikeDetailsClass[]=[];



  rentalDetails = new rentalDetailsClass;
  session: Session = new Session;
  
  onCreate(bikeid:any,rate:any){
    console.log(bikeid,rate);

    sessionStorage.setItem("bikeId",bikeid);
    

    this.rentalDetails.bikeId=bikeid;
    this.rentalDetails.userId=this.userId;
    this.rentalDetails.pickup_date=this.pickupDate;
    this.rentalDetails.pickup_time=this.pickupTime.toString();
    this.rentalDetails.drop_date=this.dropoffDate;
    this.rentalDetails.drop_time=this.dropoffTime.toString();
    this.rentalDetails.paid=this.bookedHours*rate;

    sessionStorage.setItem("paid",this.rentalDetails.paid.toString());

    console.log(this.rentalDetails);
    


    if(this.session.isLoggedIn()){
    this.router.navigate(['/summary']);
    }else{
      this.router.navigate(['/login']);
    }



    
  }
  

  ngOnInit(): void {
    this.service.getBikes().subscribe(data=>{
      this.bike_details= data;
      console.log(this.bike_details);
  })  
    

  }

}
