const Rentals = require('../../models/rental.model');
const user = require('./user');

module.exports = function (router) {

    router.get("/rentals/:id", async (req, res) => {
        const rentals = await Rentals.find({ userId: req.params.id })
            .populate("bikeId")
            .exec();

        res.status(200).json(rentals);
    });

    router.delete("/rentals/:id", function (req, res) {
        Rentals.findOne({ userId: req.params.id }, (err, book) => {
            if (err) {
                res.send(err)
            } else {
                book.remove((err, note) => {
                    if (err) {
                        res.send(err)
                    }
                    res.status(200).json(note)
                })
            }
        })
    })

    // router.post("/rentals", async (req, res) => {
    //     const rentals = await Rentals.create(req.body);
    //     res.status(201).json(rentals);
    // });
    router.post("/rentals", function (req, res) {
        let rental = new Rentals(req.body)
        rental.save(function (err, note) {
            if (err) {
                return res.status(400).json(err)
            }
            res.status(200).json(note)
        })
    })
}