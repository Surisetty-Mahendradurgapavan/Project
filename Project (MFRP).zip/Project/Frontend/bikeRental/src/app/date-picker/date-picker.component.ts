import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.css']
})
export class DatePickerComponent implements OnInit {

  constructor(
    private router:Router
  ) { }

  minDate: any;
  ngOnInit(): void {
    const temp=new Date().getFullYear();
    const temp1=new Date().getMonth();
    const temp2=new Date().getDate();
    this.minDate=new Date(temp,temp1,temp2);
  }
  pickupDate:any;
  dropoffDate:any;
  pickupTime:any;
  dropoffTime:any;
  times=[
    {
      value:8,
      text:"8:00am"
    },
    {
      value:9,
      text:"9:00am"
    },
    {
      value:10,
      text:"10:00am"
    },
    {
      value:11,
      text:"11:00am"
    },
    {
      value:12,
      text:"12:00pm"
    },
    {
      value:13,
      text:"1:00pm"
    },
    {
      value:14,
      text:"2:00pm"
    },
    {
      value:15,
      text:"3:00pm"
    },
    {
      value:16,
      text:"4:00pm"
    },
    {
      value:17,
      text:"5:00pm"
    },
    {
      value:18,
      text:"8:00pm"
    },
    {
      value:19,
      text:"7:00pm"
    },
    {
      value:20,
      text:"8:00pm"
    },
    {
      value:21,
      text:"9:00pm"
    },
    {
      value:22,
      text:"10:00pm"
    }

  ]

  clickedBookbutton(){
    
    const bookedHours=((this.dropoffDate.getTime()-this.pickupDate.getTime())/60/60000)+this.dropoffTime-this.pickupTime;

    sessionStorage.setItem("pickupDate",this.pickupDate);
    sessionStorage.setItem("dropoffDate",this.dropoffDate);
    sessionStorage.setItem("pickupTime",this.pickupTime);
    sessionStorage.setItem("dropoffTime",this.dropoffTime);
    sessionStorage.setItem("bookedHours",bookedHours.toString());

    const rate = sessionStorage.getItem("hourly_Rate");
    const paid=bookedHours*Number(rate);

    sessionStorage.setItem("paid",paid.toString());
    
   
    if(localStorage.getItem("userId")==null){
      this.router.navigate(['/login']);
    }else{
      this.router.navigate(['/summary']);
    }
  }

}
