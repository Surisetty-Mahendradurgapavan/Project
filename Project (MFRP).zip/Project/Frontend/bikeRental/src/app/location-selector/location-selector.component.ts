import { Component, OnInit } from '@angular/core';
import { locationDetailsClass } from '../Idata';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-location-selector',
  templateUrl: './location-selector.component.html',
  styleUrls: ['./location-selector.component.css']
})
export class LocationSelectorComponent implements OnInit {

  locationDetails:locationDetailsClass[]=[];

  constructor(
    public service:SharedService
  ) { }

  ngOnInit(): void {
    this.service.getLocations().subscribe(data=>{
      this.locationDetails=data;
      console.log(this.locationDetails);
    })
  }

  clicked(name:any){
    console.log(name);
    sessionStorage.setItem('location',name);
  }
}
