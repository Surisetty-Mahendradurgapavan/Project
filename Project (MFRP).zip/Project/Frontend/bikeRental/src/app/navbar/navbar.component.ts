import { Component, Input, OnInit } from '@angular/core';
import { Session } from '../session';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDialog } from '@angular/material/dialog';
import { LocationSelectorComponent } from '../location-selector/location-selector.component';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  @Input()
  session!: Session;



  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
   this.session = new Session();
  }
  logout(){
    this.session.logout();
  }
  selectLocation(){
    let dialogRef = this.dialog.open(LocationSelectorComponent);
    dialogRef.afterClosed().subscribe(result =>{
      console.log(result);
    })
  }

}
