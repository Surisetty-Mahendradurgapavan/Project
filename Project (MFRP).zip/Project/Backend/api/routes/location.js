const Location = require('../../models/location.model');

module.exports = function (router) {

    router.get("/locations", async (req, res) => {
        const location = await Location.find({}).lean().exec();
        res.status(200).json(location);
    });




    router.post("/locations", function (req, res) {
        let location = new Location(req.body)
        location.save(function (err, note) {
            if (err) {
                return res.status(400).json(err)
            }
            res.status(200).json(note)
        })
    })
}