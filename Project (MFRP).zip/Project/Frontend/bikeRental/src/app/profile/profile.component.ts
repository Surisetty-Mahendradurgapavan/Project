import { Component, OnInit } from '@angular/core';
import { pastRentalDetailsClass, rentalDetailsClass, userDetailsClass } from '../Idata';
import { SharedService } from '../shared.service';
import { Session } from '../session';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(
    public service:SharedService,
    private router:Router
  ) { }

  session: Session = new Session;


  userId:any=localStorage.getItem("userId");

  pastBookings:pastRentalDetailsClass[]=[];
  userDetails = new userDetailsClass;
  ngOnInit(): void {
    this.service.getPastRentals(this.userId).subscribe(data=>{
      this.pastBookings=data;
      console.log(this.pastBookings);
    })
    this.service.getUsers(this.userId).subscribe(data=>{
      this.userDetails=data;
    })
  }
  clicked(){
    this.session.logout();
    this.router.navigate(['/home']);
  }

}
