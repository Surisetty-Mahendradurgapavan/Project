import { Component, OnInit } from '@angular/core';
import { bikeDetailsClass } from '../Idata';
import { SharedService } from '../shared.service';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { DatePickerComponent } from '../date-picker/date-picker.component';
@Component({
  selector: 'app-tariff',
  templateUrl: './tariff.component.html',
  styleUrls: ['./tariff.component.css']
})
export class TariffComponent implements OnInit {
  
  bike_details:bikeDetailsClass[]=[];
  
  
  constructor(
    public service:SharedService,
    public dialog:MatDialog
  ) { }

  ngOnInit(): void {
    this.service.getBikes().subscribe(data=>{
      this.bike_details= data;
      console.log(this.bike_details);
    })    
  }
  openDialog(bikeId:any,hourly_rate:any){
    console.log(bikeId);
    sessionStorage.setItem("bikeId",bikeId);
    sessionStorage.setItem("hourly_Rate",hourly_rate.toString());

    const dialogConfig = new MatDialogConfig();
    this.dialog.open(DatePickerComponent,dialogConfig);
  }

}
