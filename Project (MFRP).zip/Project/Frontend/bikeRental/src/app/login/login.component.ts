import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { messages, userDetailsClass, userLogin, userRegister } from '../Idata';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    public service:SharedService,
    public router:Router
  ) { }

  userRegister = new userRegister;
  firstPassword:any;
  secondPassword:any;

  password_valid=false;
  registerClicked(){
    if (this.firstPassword==this.secondPassword){
      this.password_valid=false
      this.userRegister.password=this.firstPassword;

      this.service.registerUser(this.userRegister).subscribe(data=>{
        console.log(data);
        window.location.reload();
      })


    }
    else{
      this.password_valid=true;
    }
    console.log(this.password_valid);
    console.log(this.userRegister);

  }

  

  userLogin = new userLogin;
  somedata:any;
  logInmessage:any;

  showHomeButton=false;

  loginClicked(){
    console.log(this.userLogin);
    this.service.logInUser(this.userLogin).subscribe(data=>{
      console.log(data);
      this.somedata=data;
      
      this.logInmessage=this.somedata.message;
      if (this.logInmessage=="Success!"){


        
        localStorage.setItem("userId",this.somedata.id);

        this.showHomeButton=true;
        this.the_boolvalue="t";
        sessionStorage.setItem("loggedIn",this.the_boolvalue);
      
        if(sessionStorage.getItem("pickupDate")== null){
          this.router.navigate(['/home'])
        }else{
          this.router.navigate(['/summary'])
        }
      }
      
    })
  }


  users:userDetailsClass[]=[];
  ngOnInit(): void {
  sessionStorage.setItem("loggedIn",this.the_boolvalue)

    
    
  }

  the_boolvalue="f";

}
