import { Component, OnInit } from '@angular/core';

import { bikeDetailsClass, rentalDetailsClass } from '../Idata';
import { SharedService } from '../shared.service';
import { PaymentFormComponent } from '../payment-form/payment-form.component';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogConfig } from '@angular/material/dialog';



@Component({
  selector: 'app-summary-page',
  templateUrl: './summary-page.component.html',
  styleUrls: ['./summary-page.component.css']
})
export class SummaryPageComponent implements OnInit {

  constructor(
    public service:SharedService,
    private dialog:MatDialog
  ) { }


  rentalDetails = new rentalDetailsClass;
  bikeId:any=sessionStorage.getItem("bikeId");
  pickupDate:any=sessionStorage.getItem("pickupDate");
  pickupTime:any=sessionStorage.getItem("pickupTime");
  dropoffDate:any=sessionStorage.getItem("dropoffDate");
  dropoffTime:any=sessionStorage.getItem("dropoffTime");
  bookedHours:any=sessionStorage.getItem("bookedHours");
   
  paid:any=Number(sessionStorage.getItem("paid"));
  userId:any=localStorage.getItem("userId");

  gst=this.paid * (14/100);
  total=this.paid +this.gst +this.gst+1000;
  

  booktheBike(){
    this.rentalDetails.userId=this.userId;
    this.rentalDetails.bikeId=this.bikeId;
    this.rentalDetails.pickup_date=this.pickupDate;
    this.rentalDetails.pickup_time=this.pickupTime;
    this.rentalDetails.drop_date=this.dropoffDate;
    this.rentalDetails.drop_time=this.dropoffTime;
    this.rentalDetails.paid=this.total.toString();
   
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width="50%";
    this.dialog.open(PaymentFormComponent,dialogConfig);

  }

  bike = new bikeDetailsClass;
  ngOnInit(): void {
    this.service.getOneBike(this.bikeId).subscribe(data=>{
      this.bike=data;
      console.log(this.bike)
    })   
  }

}
