import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';



//components
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { TariffComponent } from './tariff/tariff.component';
import { OffersComponent } from './offers/offers.component';
import { BookingPageComponent } from './booking-page/booking-page.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProfileComponent } from './profile/profile.component';
import { SummaryPageComponent } from './summary-page/summary-page.component';
import { NavbarComponent } from './navbar/navbar.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {path:'login',component:LoginComponent},
  {path:'navbar',component:NavbarComponent},
  {path:'home',component:HomeComponent},
  {path:'tariff',component:TariffComponent},
  {path:'offers',component:OffersComponent},
  {path:'bookingPage',component:BookingPageComponent},
  {path:'profile',component:ProfileComponent},
  {path:'summary',component:SummaryPageComponent},
  { path: '**', component:PageNotFoundComponent  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ onSameUrlNavigation: 'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
